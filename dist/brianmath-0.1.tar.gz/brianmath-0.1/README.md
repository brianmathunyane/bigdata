# brianmath package

in the package I have recursion functions and sorting functions i.e buble sort etc

# installation

'pip install git + https://github.com/brianmathunyane/bigdata.git'
